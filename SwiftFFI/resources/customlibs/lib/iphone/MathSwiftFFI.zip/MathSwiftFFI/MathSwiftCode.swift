//
//  MathSwiftCode.swift
//  SwiftFFI
//
//  Created by Zabiullah on 27/10/16.
//  Copyright © 2016 Zabiullah. All rights reserved.
//

import Foundation


@objc

class mathSwiftCode:NSObject
{
    func addData(no1:NSInteger, no2:NSInteger)->NSInteger
    {
        let result=no1+no2;
        return result;
    }
    
    func subData(no1:NSInteger, no2:NSInteger)->NSInteger
    {
        let result=no1-no2;
        return result;
    }
    
    func mulData(no1:NSInteger, no2:NSInteger)->NSInteger
    {
        let result=no1*no2;
        return result;
    }
}
