//
//  MathSwiftWrapper.m
//  SwiftFFI
//
//  Created by Zabiullah on 27/10/16.
//  Copyright © 2016 Zabiullah. All rights reserved.
//

#import "MathSwiftWrapper.h"
#import "SwiftFFI-Swift.h"

@implementation MathSwiftWrapper


+(NSInteger) getSwiftaddData:(int) num1 number2:(int)num2{
    mathSwiftCode *addObj=[[mathSwiftCode alloc]init];
    NSInteger addResult=[addObj addDataWithNo1:num1 no2:num2];
    return (long)addResult;
}

+(NSInteger) getSwiftsubData:(int) num1 number2:(int)num2{
    mathSwiftCode *subObj=[[mathSwiftCode alloc]init];
    NSInteger subResult=[subObj subDataWithNo1:num1 no2:num2];
    return (long)subResult;

}

+(NSInteger) getSwiftmulData:(int) num1 number2:(int)num2{
    mathSwiftCode *mulObj=[[mathSwiftCode alloc]init];
    NSInteger mulResult=[mulObj mulDataWithNo1:num1 no2:num2];
    return (long)mulResult;
}

@end
