//
//  MathSwiftWrapper.h
//  SwiftFFI
//
//  Created by Zabiullah on 27/10/16.
//  Copyright © 2016 Zabiullah. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MathSwiftWrapper : NSObject
+(NSInteger) getSwiftaddData:(int) num1 number2:(int)num2;
+(NSInteger) getSwiftsubData:(int) num1 number2:(int)num2;
+(NSInteger) getSwiftmulData:(int) num1 number2:(int)num2;


@end
