//
//  MathWrapperClass.h
//  SwiftFFI
//
//  Created by Zabiullah on 27/10/16.
//  Copyright © 2016 Zabiullah. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MathWrapperClass : NSObject

+(int)add:(int)x :(int)y;
+(int)sub:(int)x :(int)y;
+(int)mul:(int)x :(int)y;

@end
