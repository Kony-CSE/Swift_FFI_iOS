//
//  MathWrapperClass.m
//  SwiftFFI
//
//  Created by Zabiullah on 27/10/16.
//  Copyright © 2016 Zabiullah. All rights reserved.
//

#import "MathWrapperClass.h"

@implementation MathWrapperClass

+(int)add:(int)x :(int)y {
    int sum = x + y;
    return sum;
}

+(int)sub:(int)x :(int)y {
    int sum = x - y;
    return sum;
}

+(int)mul:(int)x :(int)y {
    int sum = x * y;
    return sum;
}

@end
